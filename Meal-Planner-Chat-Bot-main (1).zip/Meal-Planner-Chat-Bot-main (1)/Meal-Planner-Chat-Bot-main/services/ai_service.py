import os
import json
import google.generativeai as genai
from dotenv import load_dotenv
from typing import Dict, Any

class AIService:
    def __init__(self):
        load_dotenv()
        self.api_key = os.getenv('AIzaSyDi9dguUXe03mjj1eayIFMALyJpIq_Fb4A')
        genai.configure(api_key=self.api_key)
        self.model = genai.GenerativeModel('gemini-2.0-flash')
        
        # Define allowed topics for domain-specific responses
        self.allowed_topics = [
            'meal planning',
            'nutrition',
            'dietary restrictions',
            'food allergies',
            'recipes',
            'cooking',
            'ingredients',
            'health goals',
            'calorie counting',
            'meal prep',
            'food substitutions',
            'portion control',
            'macronutrients',
            'micronutrients'
        ]
        
        # System prompt to ensure domain-specific responses
        self.system_context = """
        You are a specialized meal planning and nutrition assistant. You can only provide 
        information and answers related to meal planning, nutrition, recipes, cooking, 
        and dietary advice. If a question is outside of these topics, politely redirect 
        the conversation back to meal planning and nutrition.
        """

    def is_domain_relevant(self, query: str) -> bool:
        """Check if the user query is relevant to the meal planning domain."""
        # Create a domain-focused prompt to analyze the query
        analysis_prompt = f"""
        Determine if the following query is related to meal planning, nutrition, or cooking:
        Query: {query}
        Only respond with 'true' if it's related to allowed topics, otherwise 'false'.
        """
        
        try:
            response = self.model.generate_content(analysis_prompt)
            result = response.text.strip().lower()
            return result == 'true'
        except Exception:
            # If there's an error in analysis, default to accepting the query
            return True
        
    async def generate_meal_plan(self, preferences: Dict[str, Any]) -> Dict[str, Any]:
        # Format the prompt based on user preferences
        prompt = self._create_prompt(preferences)
        
        try:
            # Combine system context with the specific prompt
            full_prompt = f"{self.system_context}\n\n{prompt}"
            
            # Generate content using Gemini
            response = self.model.generate_content(full_prompt)
            return self._parse_response(response)
        except Exception as e:
            print(f"Error calling Gemini API: {e}")
            return {"error": str(e)}
            
    async def chat(self, message: str) -> Dict[str, Any]:
        """Handle chat messages with domain validation."""
        if not self.is_domain_relevant(message):
            return {
                "success": True,
                "response": "I can only help you with topics related to meal planning, nutrition, and cooking. Would you like to ask something about meal planning or nutrition?"
            }
            
        try:
            # Combine system context with user message
            full_prompt = f"{self.system_context}\n\nUser: {message}"
            response = self.model.generate_content(full_prompt)
            
            return {
                "success": True,
                "response": response.text
            }
        except Exception as e:
            print(f"Error in chat: {e}")
            return {
                "success": False,
                "response": "I apologize, but I encountered an error. Please try asking about meal planning or nutrition again."
            }
    
    def _create_prompt(self, preferences):
        return f"""Generate a personalized meal plan based on the following preferences:
        Dietary Restrictions: {preferences.get('dietary_preferences', [])}
        Allergies: {preferences.get('allergies', [])}
        Favorite Cuisines: {preferences.get('cuisines', [])}
        Calorie Goal: {preferences.get('daily_calorie_goal', 2000)}
        Health Goals: {preferences.get('health_goals', [])}
        Disliked Ingredients: {preferences.get('disliked_ingredients', [])}
        
        Please provide a 7-day meal plan with breakfast, lunch, dinner, and snacks for each day.
        For each meal, include:
        1. Recipe name
        2. Ingredients with quantities
        3. Brief cooking instructions
        4. Nutritional information (calories, protein, carbs, fat)
        
        Format the response as a structured JSON object.
        """
    
    def _parse_response(self, response):
        try:
            # Extract the text from the response
            text = response['candidates'][0]['content']['parts'][0]['text']
            
            # Find the JSON part in the text
            start_idx = text.find('{')
            end_idx = text.rfind('}') + 1
            
            if start_idx != -1 and end_idx != -1:
                json_str = text[start_idx:end_idx]
                meal_plan = json.loads(json_str)
                return meal_plan
            else:
                # If no JSON found, return the raw text
                return {"raw_response": text}
                
        except Exception as e:
            print(f"Error parsing response: {e}")
            return {"error": str(e), "raw_response": response}