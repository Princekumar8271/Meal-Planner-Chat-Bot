class AIHandler {
    async generateMealPlan(preferences) {
        try {
            const response = await fetch('/generate-meal-plan', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(preferences)
            });
            
            const data = await response.json();
            if (!data.success) {
                throw new Error(data.error);
            }
            
            return data.meal_plan;
        } catch (error) {
            console.error('Error generating meal plan:', error);
            throw error;
        }
    }
}

export default new AIHandler();