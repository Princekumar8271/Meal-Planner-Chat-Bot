document.addEventListener('DOMContentLoaded', function() {
    // Tab switching functionality
    const interfaceTabs = document.querySelectorAll('.interface-tab');
    const chatInterface = document.getElementById('chat-interface');
    const preferenceFormInterface = document.getElementById('preference-form-interface');
    
    interfaceTabs.forEach(tab => {
        tab.addEventListener('click', function() {
            // Remove active class from all tabs
            interfaceTabs.forEach(t => t.classList.remove('active'));
            
            // Add active class to clicked tab
            this.classList.add('active');
            
            // Show the corresponding interface
            const interfaceType = this.getAttribute('data-interface');
            
            if (interfaceType === 'chat') {
                chatInterface.classList.remove('hidden');
                preferenceFormInterface.classList.add('hidden');
            } else if (interfaceType === 'form') {
                chatInterface.classList.add('hidden');
                preferenceFormInterface.classList.remove('hidden');
            }
        });
    });
    
    // Chat functionality
    const chatMessages = document.getElementById('chat-messages');
    const userInput = document.getElementById('user-input');
    const sendBtn = document.getElementById('send-btn');
    
    async function sendMessage() {
        const message = userInput.value.trim();
        if (message) {
            // Check if message is domain-relevant using keywords
            const domainKeywords = ['meal', 'food', 'diet', 'nutrition', 'recipe', 'cook', 'eat', 'calorie', 'ingredient', 'breakfast', 'lunch', 'dinner', 'snack', 'portion', 'healthy', 'vegetarian', 'vegan', 'allergy', 'protein', 'carb', 'fat'];
            const isDomainRelevant = domainKeywords.some(keyword => 
                message.toLowerCase().includes(keyword.toLowerCase())
            );

            if (!isDomainRelevant) {
                addMessage('bot', 'I can only help with meal planning and nutrition related questions. Please ask me about food, recipes, diets, or nutrition!');
                return;
            }

            // Add user message to chat
            addMessage('user', message);
            
            // Clear input
            userInput.value = '';
            
            // Add typing indicator with animated dots
            const typingIndicator = document.createElement('div');
            typingIndicator.className = 'message bot';
            typingIndicator.innerHTML = `
                <div class="message-content">
                    <div class="typing-indicator">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                </div>
            `;
            chatMessages.appendChild(typingIndicator);
            
            // Scroll to bottom
            chatMessages.scrollTop = chatMessages.scrollHeight;
            
            try {
                // Send message to backend
                const response = await fetch('/api/chat', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ message })
                });
                
                const data = await response.json();
                
                // Remove typing indicator
                chatMessages.removeChild(typingIndicator);
                
                // Add bot response
                if (data.success) {
                    addMessage('bot', data.response);
                } else {
                    addMessage('bot', 'I apologize, but I can only help with meal planning and nutrition related questions. Would you like to ask something about meal planning?');
                }
            } catch (error) {
                console.error('Chat error:', error);
                chatMessages.removeChild(typingIndicator);
                addMessage('bot', 'I apologize, but I encountered an error. Please try asking about meal planning or nutrition again.');
            }
        }
    }
    
    function addMessage(sender, text) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${sender}`;
        messageDiv.innerHTML = `
            <div class="message-content">
                <p>${text}</p>
            </div>
        `;
        chatMessages.appendChild(messageDiv);
        
        // Scroll to bottom
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
    
    // Send message on button click
    sendBtn.addEventListener('click', sendMessage);
    
    // Send message on Enter key
    userInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });
    
    // Form submission
    const generatePlanBtn = document.getElementById('generate-plan-btn');
    if (generatePlanBtn) {
        generatePlanBtn.addEventListener('click', function() {
            // Show loading state
            this.textContent = 'Generating...';
            this.disabled = true;
            
            // Collect form data
            const preferences = collectFormData();
            
            // Simulate API call
            setTimeout(() => {
                // Reset button
                this.textContent = 'Generate My Meal Plan';
                this.disabled = false;
                
                // Show meal plan (this would be replaced with actual API call)
                showMealPlan();
            }, 2000);
        });
    }
    
    function collectFormData() {
        // Get dietary preferences
        const dietaryPreferences = Array.from(document.querySelectorAll('input[name="dietary_preferences"]:checked'))
            .map(input => input.value);
        
        // Get allergies
        const allergies = Array.from(document.querySelectorAll('input[name="allergies"]:checked'))
            .map(input => input.value);
        
        // Get cuisines
        const cuisines = Array.from(document.querySelectorAll('input[name="cuisines"]:checked'))
            .map(input => input.value);
        
        // Get other form values
        const name = document.getElementById('name').value;
        const dislikedIngredients = document.getElementById('disliked-ingredients').value.split(',').map(item => item.trim());
        const healthGoals = document.getElementById('health-goals').value.split(',').map(item => item.trim());
        const dailyCalorieGoal = document.getElementById('daily-calorie-goal').value;
        const servingsPerMeal = document.getElementById('servings-per-meal').value;
        
        return {
            dietary_preferences: dietaryPreferences,
            allergies: allergies,
            cuisines: cuisines,
            name: name,
            disliked_ingredients: dislikedIngredients,
            health_goals: healthGoals,
            daily_calorie_goal: dailyCalorieGoal,
            servings_per_meal: servingsPerMeal
        };
    }
    
    function showMealPlan() {
        // Hide form
        document.getElementById('preference-form-interface').classList.add('hidden');
        
        // Show meal plan
        document.getElementById('meal-plan-container').classList.remove('hidden');
        
        // Populate with sample data (would be replaced with actual API response)
        populateSampleMealPlan();
    }
    
    function populateSampleMealPlan() {
        // This is just a placeholder - would be replaced with actual data from API
        const dayMeals = document.getElementById('day-meals');
        dayMeals.innerHTML = `
            <div class="meal-card">
                <h3>
                    <span>Breakfast</span>
                    <span class="meal-time">8:00 AM</span>
                </h3>
                <p>Avocado Toast with Poached Eggs</p>
                <div class="meal-info">
                    <span>450 calories</span>
                    <span>22g protein</span>
                    <span>30g carbs</span>
                    <span>28g fat</span>
                </div>
            </div>
            <div class="meal-card">
                <h3>
                    <span>Lunch</span>
                    <span class="meal-time">12:30 PM</span>
                </h3>
                <p>Mediterranean Quinoa Salad</p>
                <div class="meal-info">
                    <span>380 calories</span>
                    <span>12g protein</span>
                    <span>45g carbs</span>
                    <span>18g fat</span>
                </div>
            </div>
            <div class="meal-card">
                <h3>
                    <span>Dinner</span>
                    <span class="meal-time">7:00 PM</span>
                </h3>
                <p>Grilled Salmon with Roasted Vegetables</p>
                <div class="meal-info">
                    <span>520 calories</span>
                    <span>38g protein</span>
                    <span>25g carbs</span>
                    <span>30g fat</span>
                </div>
            </div>
        `;
    }
});