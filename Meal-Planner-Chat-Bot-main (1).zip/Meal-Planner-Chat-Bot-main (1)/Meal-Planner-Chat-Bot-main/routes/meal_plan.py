from flask import Blueprint, request, jsonify
from services.ai_service import AIService

meal_plan_bp = Blueprint('meal_plan', __name__)
ai_service = AIService()

@meal_plan_bp.route('/generate-meal-plan', methods=['POST'])
async def generate_meal_plan():
    try:
        preferences = request.json
        meal_plan = await ai_service.generate_meal_plan(preferences)
        return jsonify({'success': True, 'meal_plan': meal_plan})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500